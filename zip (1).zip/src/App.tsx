/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TitleScreen } from './components/TitleScreen';
import { GameCanvas } from './components/GameCanvas';

export default function App() {
  const [gameState, setGameState] = useState<'title' | 'playing'>('title');
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleStartGame = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setGameState('playing');
      setIsTransitioning(false);
    }, 280);
  };

  const handleReturnToMenu = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setGameState('title');
      setIsTransitioning(false);
    }, 280);
  };

  return (
    <main className="w-screen h-screen bg-[#070b18] text-slate-100 overflow-hidden font-sans select-none relative">
      {/* Screen View */}
      {gameState === 'title' ? (
        <TitleScreen onStartGame={handleStartGame} />
      ) : (
        <GameCanvas onReturnToMenu={handleReturnToMenu} />
      )}

      {/* Cinematic Transition Curtain */}
      {isTransitioning && (
        <div className="absolute inset-0 bg-black z-50 animate-in fade-in duration-250 pointer-events-none" />
      )}
    </main>
  );
}
