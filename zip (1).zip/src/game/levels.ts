export interface LevelData {
  index: number;
  name: string;
  subtitle: string;
  length: number;
  bg: [string, string];
  accent: string;
  platforms: number[][]; // [x, y, w, h]
  spikes: number[][]; // [x, y, w, h]
  shards: number[][]; // [x, y]
  enemies: { x: number; y: number; hp: number; kind: 'stalker' | 'wraith'; min: number; max: number }[];
  boss: { x: number; y: number; hp: number; kind: 'abbot' | 'riftlord'; min: number; max: number } | null;
  portalX: number;
}

export const LEVELS: LevelData[] = [
  {
    index: 0,
    name: 'The Shattered Canopy',
    subtitle: 'Learn to trust the ceiling.',
    length: 1760,
    bg: ['#15264a', '#091122'],
    accent: '#75f4e8',
    platforms: [
      // Ground platforms
      [0, 420, 260, 22],
      [320, 360, 150, 18],
      [520, 420, 150, 22],
      [740, 325, 155, 18],
      [970, 420, 190, 22],
      [1210, 350, 160, 18],
      [1450, 420, 310, 22],
      // Inverted ceiling platforms
      [180, 100, 160, 16],
      [440, 135, 150, 16],
      [680, 85, 160, 16],
      [1010, 115, 170, 16],
      [1280, 95, 160, 16],
    ],
    spikes: [
      [260, 400, 58, 20],
      [670, 400, 60, 20],
      [1160, 400, 48, 20],
    ],
    shards: [
      [375, 325],
      [795, 290],
      [1320, 310],
    ],
    enemies: [
      { x: 565, y: 382, hp: 2, kind: 'stalker', min: 530, max: 640 },
      { x: 1040, y: 382, hp: 2, kind: 'stalker', min: 1000, max: 1120 },
    ],
    boss: null,
    portalX: 1680,
  },
  {
    index: 1,
    name: 'The Upside-Down Abbey',
    subtitle: 'The world remembers both sides.',
    length: 1900,
    bg: ['#292044', '#0b1022'],
    accent: '#d58cff',
    platforms: [
      // Ground platforms
      [0, 420, 220, 22],
      [285, 350, 130, 18],
      [475, 420, 150, 22],
      [700, 300, 145, 18],
      [920, 420, 180, 22],
      [1160, 340, 145, 18],
      [1380, 420, 180, 22],
      [1640, 350, 240, 18],
      // Inverted ceiling platforms
      [130, 95, 170, 16],
      [390, 125, 160, 16],
      [635, 80, 170, 16],
      [885, 110, 170, 16],
      [1125, 85, 170, 16],
      [1390, 115, 170, 16],
      [1630, 95, 170, 16],
    ],
    spikes: [
      [220, 400, 60, 20],
      [625, 400, 65, 20],
      [1100, 400, 55, 20],
      [1560, 400, 65, 20],
    ],
    shards: [
      [335, 315],
      [965, 385],
      [1440, 380],
    ],
    enemies: [
      { x: 515, y: 382, hp: 2, kind: 'stalker', min: 490, max: 600 },
      { x: 1220, y: 302, hp: 3, kind: 'wraith', min: 1170, max: 1280 },
    ],
    boss: { x: 1690, y: 305, hp: 7, kind: 'abbot', min: 1635, max: 1815 },
    portalX: 1810,
  },
  {
    index: 2,
    name: 'The Riftheart Citadel',
    subtitle: 'One final guardian. Two realities.',
    length: 2050,
    bg: ['#3b1d42', '#0b0d20'],
    accent: '#ff658f',
    platforms: [
      // Ground platforms
      [0, 420, 250, 22],
      [310, 340, 140, 18],
      [520, 420, 160, 22],
      [750, 300, 150, 18],
      [970, 420, 170, 22],
      [1200, 335, 150, 18],
      [1430, 420, 160, 22],
      [1640, 330, 140, 18],
      [1840, 420, 205, 22],
      // Inverted ceiling platforms
      [160, 95, 170, 16],
      [420, 130, 170, 16],
      [680, 80, 160, 16],
      [940, 115, 170, 16],
      [1190, 85, 160, 16],
      [1450, 110, 160, 16],
      [1710, 85, 170, 16],
    ],
    spikes: [
      [250, 400, 60, 20],
      [680, 400, 65, 20],
      [1140, 400, 60, 20],
      [1590, 400, 50, 20],
      [1780, 400, 60, 20],
    ],
    shards: [
      [365, 305],
      [1005, 380],
      [1490, 375],
    ],
    enemies: [
      { x: 570, y: 382, hp: 3, kind: 'stalker', min: 540, max: 630 },
      { x: 1270, y: 297, hp: 3, kind: 'wraith', min: 1220, max: 1310 },
    ],
    boss: { x: 1770, y: 282, hp: 10, kind: 'riftlord', min: 1660, max: 1930 },
    portalX: 1960,
  },
];
