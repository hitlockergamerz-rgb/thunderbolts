import { Enemy, GameMode, InputState, Particle, Platform, Player, Portal, RelicId, Shard, Spike } from '../types/game';
import { sounds } from './audio';
import { LevelData, LEVELS } from './levels';
import { GameRenderer } from './renderer';
import { gameStorage } from './storage';

export class GameEngine {
  public canvas: HTMLCanvasElement;
  public ctx: CanvasRenderingContext2D;
  private renderer: GameRenderer;

  public mode: GameMode = 'play';
  public levelIndex: number = 0;
  public level: LevelData = LEVELS[0];
  public levelTime: number = 0;
  public camera: number = 0;

  public platforms: Platform[] = [];
  public spikes: Spike[] = [];
  public shards: Shard[] = [];
  public enemies: Enemy[] = [];
  public portal: Portal = { x: 0, y: 0, w: 40, h: 60 };
  public particles: Particle[] = [];

  public player: Player;
  public keys: Record<string, boolean> = {};

  public shake: number = 0;
  public toast: string = '';
  public toastTime: number = 0;
  public flipCd: number = 0;
  public attackCd: number = 0;
  public screenFlash: number = 0;

  public paused: boolean = false;
  private isRunning: boolean = false;
  private animId: number | null = null;
  private lastTime: number = 0;

  public onStateChange?: () => void;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Cannot get 2d context');
    this.ctx = ctx;

    this.renderer = new GameRenderer();
    this.player = this.createDefaultPlayer();
    this.loadLevel(0, false);
  }

  private createDefaultPlayer(): Player {
    return {
      x: 60,
      y: 0,
      w: 27,
      h: 36,
      vx: 0,
      vy: 0,
      grav: 1,
      ground: false,
      hp: 4,
      maxHp: 4,
      face: 1,
      attackTimer: 0,
      shield: false,
      speed: 3.5,
      jump: 10.7,
      damage: 1,
      flipPower: 1,
      invuln: 0,
      rotation: 0,
    };
  }

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = performance.now();
    sounds.startAtmosphericDrone(this.levelIndex);
    this.loop(this.lastTime);
  }

  public stop() {
    this.isRunning = false;
    if (this.animId !== null) {
      cancelAnimationFrame(this.animId);
      this.animId = null;
    }
  }

  public loadLevel(index: number, keepStats = true) {
    this.levelIndex = index;
    this.level = LEVELS[index];
    this.levelTime = 0;
    this.camera = 0;
    this.particles = [];
    this.flipCd = 0;
    this.attackCd = 0;
    this.shake = 0;
    this.toast = '';
    this.toastTime = 0;
    this.screenFlash = 0;

    // Load platforms
    this.platforms = this.level.platforms.map((p) => ({
      x: p[0],
      y: p[1],
      w: p[2],
      h: p[3],
    }));

    // Load spikes
    this.spikes = this.level.spikes.map((s) => ({
      x: s[0],
      y: s[1],
      w: s[2],
      h: s[3],
    }));

    // Load shards
    this.shards = this.level.shards.map((s, idx) => ({
      id: `shard-${idx}`,
      x: s[0],
      y: s[1],
      got: false,
    }));

    // Load enemies
    this.enemies = this.level.enemies.map((e, idx) => ({
      id: `enemy-${idx}`,
      x: e.x,
      y: e.y,
      w: e.kind === 'wraith' ? 28 : 30,
      h: e.kind === 'wraith' ? 30 : 38,
      vx: 0,
      hp: e.hp,
      maxHp: e.hp,
      kind: e.kind,
      min: e.min,
      max: e.max,
      dir: 1,
      stun: 0,
      attack: 0,
      phase: 0,
      boss: false,
    }));

    // Load boss if present
    if (this.level.boss) {
      const b = this.level.boss;
      this.enemies.push({
        id: 'boss',
        x: b.x,
        y: b.y,
        w: b.kind === 'riftlord' ? 54 : 48,
        h: b.kind === 'riftlord' ? 62 : 55,
        vx: 0,
        hp: b.hp,
        maxHp: b.hp,
        kind: b.kind,
        min: b.min,
        max: b.max,
        dir: -1,
        stun: 0,
        attack: 0,
        phase: 0,
        boss: true,
      });
    }

    // Portal position
    this.portal = {
      x: this.level.portalX,
      y: this.levelIndex === 0 ? 360 : this.levelIndex === 1 ? 290 : 360,
      w: 40,
      h: 60,
    };

    // Position player on starting platform
    this.player.x = 55;
    this.player.y = this.platforms[0].y - this.player.h;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.grav = 1;
    this.player.ground = true;
    this.player.attackTimer = 0;
    this.player.invuln = 0;

    if (!keepStats) {
      this.player.hp = 4;
      this.player.maxHp = 4;
      this.player.speed = 3.5;
      this.player.jump = 10.7;
      this.player.damage = 1;
      this.player.flipPower = 1;
    }

    sounds.updateDroneTone(this.levelIndex);
    this.mode = 'play';
    if (this.onStateChange) this.onStateChange();
  }

  public burst(x: number, y: number, color: string, n = 14) {
    for (let i = 0; i < n; i++) {
      this.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 6,
        vy: (Math.random() - 0.5) * 6,
        life: 22 + Math.random() * 30,
        max: 52,
        color,
        size: 2 + Math.random() * 3,
      });
    }
  }

  public say(text: string) {
    this.toast = text;
    this.toastTime = 90;
  }

  public keyAction(k: 'flip' | 'attack') {
    if (this.mode !== 'play' || this.paused) return;

    if (k === 'flip' && this.flipCd <= 0) {
      this.player.grav = this.player.grav === 1 ? -1 : 1;
      this.player.vy = this.player.grav * 2.2;
      this.flipCd = Math.max(18, 48 - this.player.flipPower * 8);
      this.burst(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, '#75f7f3', 22);
      this.screenFlash = 10;
      sounds.playFlip(this.player.grav);
      this.say('GRAVITY INVERTED');
      gameStorage.unlockAchievement('gravity_shift');
      if (this.onStateChange) this.onStateChange();
    }

    if (k === 'attack' && this.attackCd <= 0) {
      this.player.attackTimer = 13;
      this.attackCd = 25;
      sounds.playSwordSlash();

      let hit = false;
      const pCenterX = this.player.x + this.player.w / 2;
      const pCenterY = this.player.y + this.player.h / 2;

      for (const e of this.enemies) {
        if (e.hp <= 0) continue;
        const eCenterX = e.x + e.w / 2;
        const eCenterY = e.y + e.h / 2;

        const dist = Math.abs(eCenterX - pCenterX);
        const distY = Math.abs(eCenterY - pCenterY);

        if (dist < 75 && distY < 75 && (Math.sign(eCenterX - pCenterX) === this.player.face || dist < 25)) {
          let dmg = this.player.damage;

          // Guardian Vulnerability Bonus Window
          if (e.boss && e.phase % 2 === 0 && this.levelTime % 180 > 80) {
            dmg += 1;
            this.say('GUARDIAN EXPOSED · BONUS DAMAGE');
          }

          e.hp -= dmg;
          e.stun = e.boss ? 13 : 22;
          e.phase++;
          this.burst(eCenterX, eCenterY, e.boss ? '#e7a0ff' : '#ff9ab5', 14);
          sounds.playEnemyHit(e.boss);
          hit = true;

          if (e.hp <= 0) {
            this.burst(eCenterX, eCenterY, '#8bfff2', 30);
            this.say(e.boss ? 'GUARDIAN SHATTERED' : 'SHADOW DISPERSED');
            if (e.boss) {
              gameStorage.unlockAchievement('guardian_conqueror');
            } else {
              gameStorage.unlockAchievement('shadow_slayer');
            }
          }
        }
      }


      if (!hit) {
        this.burst(pCenterX + this.player.face * 26, pCenterY, '#bcefff', 4);
      }
      if (this.onStateChange) this.onStateChange();
    }
  }

  public hurt(fall = false) {
    if (this.player.invuln > 0) return;

    this.player.hp--;
    this.player.invuln = 90;
    this.player.vy = -this.player.grav * 5;
    this.shake = 10;
    this.screenFlash = 8;
    sounds.playHurt();
    this.burst(this.player.x + 14, this.player.y + 18, '#ff668f', 20);

    if (fall) {
      this.player.x = Math.max(40, this.player.x - 100);
      this.player.y = this.player.grav === 1 ? this.platforms[0].y - this.player.h : 45;
      this.player.vy = 0;
    }

    if (this.onStateChange) this.onStateChange();

    if (this.player.hp <= 0) {
      this.mode = 'dead';
      if (this.onStateChange) this.onStateChange();
    }
  }

  public applyUpgrade(type: RelicId) {
    if (type === 'heart') {
      this.player.maxHp = Math.min(6, this.player.maxHp + 1);
      this.player.hp = this.player.maxHp;
    } else if (type === 'blade') {
      this.player.damage++;
    } else if (type === 'boots') {
      this.player.speed += 0.45;
      this.player.jump += 0.5;
    } else if (type === 'rift') {
      this.player.flipPower = Math.min(3, this.player.flipPower + 1);
    }

    sounds.playUpgrade();
    this.say('RELIC ATTUNED');

    if (this.levelIndex < 2) {
      this.loadLevel(this.levelIndex + 1, true);
    } else {
      this.mode = 'ending';
      gameStorage.unlockAchievement('reality_restored');
    }
    if (this.onStateChange) this.onStateChange();

  }

  private loop = (currentTime: number) => {
    if (!this.isRunning) return;

    const dt = Math.min(2, (currentTime - this.lastTime) / 16.67 || 1);
    this.lastTime = currentTime;

    this.update(dt);
    this.render();

    this.animId = requestAnimationFrame(this.loop);
  };

  private update(dt: number) {
    if (this.mode !== 'play' || this.paused) return;

    this.levelTime += dt;
    this.flipCd = Math.max(0, this.flipCd - dt);
    this.attackCd = Math.max(0, this.attackCd - dt);
    this.player.invuln = Math.max(0, this.player.invuln - dt);
    this.player.attackTimer = Math.max(0, this.player.attackTimer - dt);
    this.toastTime = Math.max(0, this.toastTime - dt);
    this.shake = Math.max(0, this.shake - dt);
    this.screenFlash = Math.max(0, this.screenFlash - dt);

    // Horizontal Controls
    const left = this.keys.left || this.keys.ArrowLeft || this.keys.a || this.keys.A;
    const right = this.keys.right || this.keys.ArrowRight || this.keys.d || this.keys.D;
    this.player.vx = ((right ? 1 : 0) - (left ? 1 : 0)) * this.player.speed;
    if (this.player.vx !== 0) {
      this.player.face = Math.sign(this.player.vx) as 1 | -1;
    }

    // Jump
    const jump = this.keys.jump || this.keys[' '] || this.keys.ArrowUp || this.keys.w || this.keys.W;
    if (jump && this.player.ground) {
      this.player.vy = -this.player.grav * this.player.jump;
      this.player.ground = false;
      this.burst(
        this.player.x + 13,
        this.player.grav === 1 ? this.player.y + this.player.h : this.player.y,
        '#8daaff',
        5
      );
      sounds.playJump();
    }

    // Gravity pull
    this.player.vy += this.player.grav * 0.48 * dt;
    this.player.vy = Math.max(-13, Math.min(13, this.player.vy));

    const oldY = this.player.y;
    this.player.x += this.player.vx * dt;
    this.player.x = Math.max(0, Math.min(this.level.length - this.player.w, this.player.x));
    this.player.y += this.player.vy * dt;
    this.player.ground = false;

    // Platform Collisions
    for (const p of this.platforms) {
      if (this.player.x + this.player.w > p.x && this.player.x < p.x + p.w) {
        if (this.player.grav === 1 && oldY + this.player.h <= p.y + 4 && this.player.y + this.player.h >= p.y) {
          this.player.y = p.y - this.player.h;
          this.player.vy = 0;
          this.player.ground = true;
        } else if (this.player.grav === -1 && oldY >= p.y + p.h - 4 && this.player.y <= p.y + p.h) {
          this.player.y = p.y + p.h;
          this.player.vy = 0;
          this.player.ground = true;
        }
      }
    }

    // Abyss Fall
    if (this.player.y > 500 + 200 || this.player.y < -200) {
      this.hurt(true);
    }

    // Shard Collection
    for (const s of this.shards) {
      if (!s.got && this.checkOverlap(this.player, { x: s.x - 10, y: s.y - 10, w: 20, h: 20 })) {
        s.got = true;
        this.burst(s.x, s.y, '#75f4e8', 22);
        this.say('ECHO SHARD RECOVERED');
        sounds.playShardCollect();
        gameStorage.unlockAchievement('first_shard');
        if (this.onStateChange) this.onStateChange();
      }
    }


    // Enemy AI & Updates
    for (const e of this.enemies) {
      if (e.hp <= 0) continue;
      e.attack += dt;

      if (e.stun > 0) {
        e.stun -= dt;
      } else {
        const dx = this.player.x - e.x;
        if (e.boss) {
          if (e.attack > 95) {
            e.dir = Math.sign(dx) || 1;
            e.vx = e.dir * (e.kind === 'riftlord' ? 2.15 : 1.6);
            e.attack = 0;
            this.burst(e.x + e.w / 2, e.y + e.h / 2, '#d78cff', 8);
            sounds.playBossDash();
          } else {
            e.vx = dx < 0 ? -0.45 : 0.45;
          }
          if (Math.abs(dx) < 100 && e.attack > 70) {
            e.vx = e.dir * 2.7;
          }
        } else {
          e.vx = (Math.abs(dx) < 250 ? Math.sign(dx) : e.dir) * (e.kind === 'wraith' ? 1.2 : 0.85);
          if (Math.abs(dx) > 250) {
            e.dir = Math.sign(Math.sin(this.levelTime / 40)) || 1;
          }
        }

        e.x += e.vx * dt;
        if (e.x < e.min) {
          e.x = e.min;
          e.dir = 1;
        }
        if (e.x + e.w > e.max) {
          e.x = e.max - e.w;
          e.dir = -1;
        }
      }

      // Enemy Player Contact
      if (this.checkOverlap(this.player, e) && this.player.invuln <= 0) {
        if (this.player.shield) {
          e.stun = 2; // Shield reflects and stuns enemy!
          this.burst(this.player.x + 14, this.player.y + 18, '#6af4ff', 8);
        } else {
          this.hurt(false);
        }
      }
    }

    // Spike Hazards
    for (const s of this.spikes) {
      if (this.checkOverlap(this.player, s) && this.player.invuln <= 0) {
        this.hurt(false);
      }
    }

    // Particle Updates
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.99;
      p.vy *= 0.99;
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }

    // Camera follow player smoothly
    const renderWidth = this.canvas.width / (window.devicePixelRatio || 1);
    this.camera = Math.max(0, Math.min(this.level.length - renderWidth, this.player.x - renderWidth * 0.32));

    // Portal Completion Check
    if (this.checkOverlap(this.player, this.portal)) {
      const allShards = this.shards.every((s) => s.got);
      const bossDead = !this.level.boss || this.enemies.every((e) => !e.boss || e.hp <= 0);

      if (allShards && bossDead) {
        this.mode = 'clear';
        if (this.onStateChange) this.onStateChange();
      } else if (this.toastTime < 10) {
        this.say(!bossDead ? 'DEFEAT THE GUARDIAN' : 'COLLECT ALL SHARDS');
      }
    }
  }

  private checkOverlap(
    a: { x: number; y: number; w: number; h: number },
    b: { x: number; y: number; w: number; h: number }
  ): boolean {
    return (
      a.x < b.x + b.w &&
      a.x + a.w > b.x &&
      a.y < b.y + b.h &&
      a.y + a.h > b.y
    );
  }

  private render() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = this.canvas.width / dpr;
    const h = this.canvas.height / dpr;

    this.renderer.render(
      this.ctx,
      w,
      h,
      this.level,
      this.player,
      this.platforms,
      this.spikes,
      this.shards,
      this.enemies,
      this.portal,
      this.particles,
      this.camera,
      this.shake,
      this.toast,
      this.toastTime,
      this.screenFlash,
      this.levelTime,
      this.paused
    );
  }
}
