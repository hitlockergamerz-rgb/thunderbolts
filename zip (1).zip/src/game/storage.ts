import { Achievement, GameSettings, PlayerProfile } from '../types/game';

const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  ambientDrone: true,
  screenShake: true,
  particleEffects: true,
};

const DEFAULT_PROFILE: PlayerProfile = {
  name: 'Player',
  title: 'The Lost Wanderer',
  level: 1,
};

const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_shard',
    title: 'FIRST SHARD',
    description: 'Recover an ancient Echo Shard from the fractured realm.',
    icon: '💎',
    unlocked: false,
  },
  {
    id: 'gravity_shift',
    title: 'GRAVITY SHIFT',
    description: 'Successfully manipulate gravity to walk on inverted ruins.',
    icon: '⇅',
    unlocked: false,
  },
  {
    id: 'shadow_slayer',
    title: 'SHADOW SLAYER',
    description: 'Disperse a patrolling shadow stalker or wraith with your blade.',
    icon: '⚔️',
    unlocked: false,
  },
  {
    id: 'guardian_conqueror',
    title: 'GUARDIAN CONQUEROR',
    description: 'Shatter an ancient realm guardian in direct combat.',
    icon: '👑',
    unlocked: false,
  },
  {
    id: 'reality_restored',
    title: 'REALITY RESTORED',
    description: 'Seal the fracture and unite the echoes of two worlds.',
    icon: '✨',
    unlocked: false,
  },
];

class StorageManager {
  private settings: GameSettings = DEFAULT_SETTINGS;
  private profile: PlayerProfile = DEFAULT_PROFILE;
  private achievements: Achievement[] = DEFAULT_ACHIEVEMENTS;

  constructor() {
    this.load();
  }

  private load() {
    if (typeof window === 'undefined') return;
    try {
      const s = localStorage.getItem('inversion_settings');
      if (s) this.settings = { ...DEFAULT_SETTINGS, ...JSON.parse(s) };

      const p = localStorage.getItem('inversion_profile');
      if (p) this.profile = { ...DEFAULT_PROFILE, ...JSON.parse(p) };

      const a = localStorage.getItem('inversion_achievements');
      if (a) {
        const storedA: Achievement[] = JSON.parse(a);
        this.achievements = DEFAULT_ACHIEVEMENTS.map((def) => {
          const match = storedA.find((item) => item.id === def.id);
          return match ? { ...def, unlocked: match.unlocked, unlockedAt: match.unlockedAt } : def;
        });
      }
    } catch {
      // Storage unavailable or blocked
    }
  }

  public getSettings(): GameSettings {
    return { ...this.settings };
  }

  public saveSettings(next: Partial<GameSettings>) {
    this.settings = { ...this.settings, ...next };
    try {
      localStorage.setItem('inversion_settings', JSON.stringify(this.settings));
    } catch {}
  }

  public getProfile(): PlayerProfile {
    return { ...this.profile };
  }

  public saveProfile(next: Partial<PlayerProfile>) {
    this.profile = { ...this.profile, ...next };
    try {
      localStorage.setItem('inversion_profile', JSON.stringify(this.profile));
    } catch {}
  }

  public getAchievements(): Achievement[] {
    return [...this.achievements];
  }

  public unlockAchievement(id: string): boolean {
    const ach = this.achievements.find((a) => a.id === id);
    if (ach && !ach.unlocked) {
      ach.unlocked = true;
      ach.unlockedAt = new Date().toLocaleTimeString();
      try {
        localStorage.setItem('inversion_achievements', JSON.stringify(this.achievements));
      } catch {}
      return true;
    }
    return false;
  }
}

export const gameStorage = new StorageManager();
