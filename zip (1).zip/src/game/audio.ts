class SoundSystem {
  private ctx: AudioContext | null = null;
  private soundOn: boolean = true;
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private droneGain: GainNode | null = null;
  private isDroneActive: boolean = false;

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setSoundOn(on: boolean) {
    this.soundOn = on;
    if (this.droneGain && this.ctx) {
      this.droneGain.gain.setValueAtTime(on ? 0.04 : 0, this.ctx.currentTime);
    }
  }

  public getSoundOn(): boolean {
    return this.soundOn;
  }

  public playTone(freq = 440, dur = 0.08, type: OscillatorType = 'sine', vol = 0.04) {
    if (!this.soundOn) return;
    this.init();
    if (!this.ctx) return;

    try {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, this.ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.55), this.ctx.currentTime + dur);
      g.gain.setValueAtTime(vol, this.ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
      o.connect(g);
      g.connect(this.ctx.destination);
      o.start();
      o.stop(this.ctx.currentTime + dur);
    } catch {
      // AudioContext policy
    }
  }

  // Pre-configured sound effects matching reference
  public playJump() {
    this.playTone(360, 0.07, 'sine', 0.04);
  }

  public playFlip(grav: number) {
    this.playTone(grav === -1 ? 620 : 380, 0.16, 'sawtooth', 0.05);
  }

  public playSwordSlash() {
    this.playTone(250, 0.09, 'triangle', 0.045);
  }

  public playEnemyHit(isBoss = false) {
    this.playTone(isBoss ? 140 : 190, 0.12, 'square', 0.05);
  }

  public playBossDash() {
    this.playTone(120, 0.13, 'sawtooth', 0.06);
  }

  public playShardCollect() {
    this.playTone(760, 0.18, 'sine', 0.05);
  }

  public playHurt() {
    this.playTone(100, 0.2, 'sawtooth', 0.06);
  }

  public playUpgrade() {
    this.playTone(520, 0.12, 'triangle', 0.06);
  }

  public startAtmosphericDrone(levelIndex = 0) {
    if (this.isDroneActive) {
      this.updateDroneTone(levelIndex);
      return;
    }
    this.init();
    if (!this.ctx) return;

    try {
      this.droneGain = this.ctx.createGain();
      this.droneGain.gain.setValueAtTime(this.soundOn ? 0.035 : 0, this.ctx.currentTime);

      this.droneOsc1 = this.ctx.createOscillator();
      this.droneOsc2 = this.ctx.createOscillator();

      this.droneOsc1.type = 'sine';
      this.droneOsc2.type = 'triangle';

      const baseFreq = 98 - levelIndex * 12;
      this.droneOsc1.frequency.setValueAtTime(baseFreq, this.ctx.currentTime);
      this.droneOsc2.frequency.setValueAtTime(baseFreq * 1.5, this.ctx.currentTime);

      this.droneOsc1.connect(this.droneGain);
      this.droneOsc2.connect(this.droneGain);
      this.droneGain.connect(this.ctx.destination);

      this.droneOsc1.start();
      this.droneOsc2.start();
      this.isDroneActive = true;
    } catch {
      // Ignored
    }
  }

  public updateDroneTone(levelIndex: number) {
    if (!this.ctx || !this.droneOsc1 || !this.droneOsc2) return;
    const now = this.ctx.currentTime;
    const baseFreq = 98 - levelIndex * 12;
    this.droneOsc1.frequency.exponentialRampToValueAtTime(baseFreq, now + 0.5);
    this.droneOsc2.frequency.exponentialRampToValueAtTime(baseFreq * 1.5, now + 0.5);
  }
}

export const sounds = new SoundSystem();
