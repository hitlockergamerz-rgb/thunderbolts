export const VIRTUAL_WIDTH = 1280;
export const VIRTUAL_HEIGHT = 720;

export const GRAVITY_STRENGTH = 1400; // pixels / sec^2
export const MOVE_SPEED = 320;
export const ACCELERATION = 2200;
export const FRICTION = 1800;
export const JUMP_IMPULSE = 520;
export const MAX_FALL_SPEED = 850;

export const INVERSION_COOLDOWN = 0.45; // seconds between gravity switches

export const PALETTES = {
  NORMAL: {
    name: 'Aethelgard (Normal)',
    skyTop: '#0a0d18',
    skyBottom: '#141e33',
    mountainFar: '#121b2f',
    mountainMid: '#1a2742',
    mountainNear: '#233454',
    ruinsFar: '#1d273a',
    templeStone: '#2a354b',
    templeStoneTop: '#3e4f6e',
    stoneHighlight: '#5b719c',
    mossColor: '#2b5344',
    crystalCyan: '#38bdf8',
    crystalGlow: 'rgba(56, 189, 248, 0.45)',
    ambientDust: 'rgba(147, 197, 253, 0.35)',
    runeGlow: '#67e8f9',
    accent: '#38bdf8',
    fogColor: 'rgba(15, 23, 42, 0.4)',
  },
  INVERTED: {
    name: 'The Abyssal Rift (Inverted)',
    skyTop: '#18071a',
    skyBottom: '#2d0f28',
    mountainFar: '#270c23',
    mountainMid: '#391234',
    mountainNear: '#4c1945',
    ruinsFar: '#33132d',
    templeStone: '#3d1c34',
    templeStoneTop: '#5a264a',
    stoneHighlight: '#7c3866',
    mossColor: '#4c1d3c',
    crystalCyan: '#e879f9',
    crystalGlow: 'rgba(232, 121, 249, 0.55)',
    ambientDust: 'rgba(244, 114, 182, 0.45)',
    runeGlow: '#f43f5e',
    accent: '#f43f5e',
    fogColor: 'rgba(30, 8, 28, 0.45)',
  },
};
