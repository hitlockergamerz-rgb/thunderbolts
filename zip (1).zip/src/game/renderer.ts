import { Enemy, Particle, Platform, Player, Portal, Shard, Spike } from '../types/game';
import { LevelData } from './levels';

export class GameRenderer {
  public render(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    level: LevelData,
    player: Player,
    platforms: Platform[],
    spikes: Spike[],
    shards: Shard[],
    enemies: Enemy[],
    portal: Portal,
    particles: Particle[],
    camera: number,
    shake: number,
    toast: string,
    toastTime: number,
    screenFlash: number,
    levelTime: number,
    paused: boolean
  ) {
    // 1. Clear Screen
    ctx.clearRect(0, 0, width, height);

    // 2. Parallax Sky Gradient
    const sky = ctx.createLinearGradient(0, 0, 0, height);
    sky.addColorStop(0, level.bg[0]);
    sky.addColorStop(1, level.bg[1]);
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, width, height);

    // 3. Parallax Celestial Moon / Eclipse
    ctx.save();
    const moonX = width * 0.78 - camera * 0.03;
    const moonY = 65;
    ctx.globalAlpha = 0.18;
    ctx.fillStyle = '#d2dfff';
    ctx.beginPath();
    ctx.arc(moonX, moonY, 40, 0, Math.PI * 2);
    ctx.fill();

    // Soft moon corona glow
    const moonGlow = ctx.createRadialGradient(moonX, moonY, 15, moonX, moonY, 90);
    moonGlow.addColorStop(0, 'rgba(117, 244, 232, 0.25)');
    moonGlow.addColorStop(1, 'rgba(117, 244, 232, 0)');
    ctx.fillStyle = moonGlow;
    ctx.beginPath();
    ctx.arc(moonX, moonY, 90, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // 4. Distant Parallax Stars
    ctx.save();
    for (let i = 0; i < 75; i++) {
      const sx = ((i * 139 + 17 - camera * 0.08) % (width + 40) + width + 40) % (width + 40);
      const sy = (i * 67) % Math.max(100, height * 0.65);
      const twinkle = Math.sin(levelTime * 0.05 + i) * 0.3 + 0.7;
      ctx.globalAlpha = (0.2 + (i % 5) * 0.14) * twinkle;
      ctx.fillStyle = i % 5 === 0 ? '#a5faff' : '#a3b8f3';
      ctx.fillRect(sx, sy, i % 8 === 0 ? 2 : 1, i % 8 === 0 ? 2 : 1);
    }
    ctx.restore();

    // 5. World Space (Camera Translation & Screen Shake)
    ctx.save();
    const shakeOffset = shake > 0 ? Math.sin(levelTime * 4) * shake : 0;
    ctx.translate(-camera + shakeOffset, 0);

    // Background Temple Columns & Archways (Parallax factor)
    const colSpacing = 145;
    const totalCols = Math.ceil(level.length / colSpacing);
    for (let i = 0; i < totalCols; i++) {
      const colX = i * colSpacing;
      // Sanctuary Pillar
      ctx.fillStyle = '#17294a';
      ctx.fillRect(colX, 235 + (i % 3) * 22, 55, 250);
      // Capital / Pediment
      ctx.fillStyle = '#2b3b65';
      ctx.fillRect(colX + 7, 210 + (i % 3) * 22, 42, 27);
      // Fluting Lines
      ctx.strokeStyle = '#324a77';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(colX + 14, 245);
      ctx.lineTo(colX + 14, 390);
      ctx.moveTo(colX + 41, 245);
      ctx.lineTo(colX + 41, 390);
      ctx.stroke();

      // Subtle glowing rune on pillar
      if (i % 2 === 0) {
        ctx.fillStyle = level.accent;
        ctx.globalAlpha = 0.35 + Math.sin(levelTime * 0.08 + i) * 0.15;
        ctx.fillRect(colX + 24, 270, 7, 20);
        ctx.globalAlpha = 1;
      }
    }

    // Platforms
    for (const p of platforms) {
      // Main stone body
      ctx.fillStyle = '#26375c';
      ctx.fillRect(p.x, p.y, p.w, p.h);

      // Top highlighted surface
      ctx.fillStyle = '#69b8d5';
      ctx.fillRect(p.x, p.y, p.w, 3);

      // Bottom shadow rim
      ctx.fillStyle = '#111b35';
      ctx.fillRect(p.x, p.y + p.h - 4, p.w, 4);

      // Stone brick seams
      ctx.fillStyle = '#38527b';
      for (let x = p.x + 10; x < p.x + p.w; x += 30) {
        ctx.fillRect(x, p.y + 7, 12, 2);
      }

      // Overgrown moss or crystal accent
      if (p.w >= 100) {
        ctx.fillStyle = '#3db89d';
        ctx.fillRect(p.x + 18, p.y + 1, 14, 2);
        ctx.fillRect(p.x + p.w - 32, p.y + 1, 14, 2);
      }
    }

    // Hazards: Obsidian Void Spikes
    for (const s of spikes) {
      ctx.fillStyle = '#fa638f';
      const spikeW = 12;
      for (let x = s.x; x < s.x + s.w; x += spikeW) {
        ctx.beginPath();
        ctx.moveTo(x, s.y + s.h);
        ctx.lineTo(x + spikeW * 0.5, s.y);
        ctx.lineTo(x + spikeW, s.y + s.h);
        ctx.closePath();
        ctx.fill();

        // Tip glow
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(x + spikeW * 0.5 - 1, s.y, 2, 3);
        ctx.fillStyle = '#fa638f';
      }
    }

    // Echo Shards
    for (const s of shards) {
      if (s.got) continue;
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(levelTime * 0.05);

      ctx.shadowBlur = 20;
      ctx.shadowColor = '#75fff1';

      // Spinning Outer Rhombus
      ctx.fillStyle = '#91fff5';
      ctx.beginPath();
      ctx.moveTo(0, -13);
      ctx.lineTo(10, 0);
      ctx.lineTo(0, 13);
      ctx.lineTo(-10, 0);
      ctx.closePath();
      ctx.fill();

      // Inner Core
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(0, -6);
      ctx.lineTo(5, 0);
      ctx.lineTo(0, 6);
      ctx.lineTo(-5, 0);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }

    // Realm Portal / Obelisk
    ctx.save();
    const portalCenterX = portal.x + portal.w / 2;
    const portalCenterY = portal.y + portal.h / 2;
    ctx.translate(portalCenterX, portalCenterY);

    ctx.shadowBlur = 28;
    ctx.shadowColor = '#a084ff';

    // Outer swirling portal ellipse
    ctx.strokeStyle = '#9d8cff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.ellipse(0, 0, 22, 32, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Inner bright cyan aperture
    ctx.strokeStyle = '#77f8ff';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(0, 0, 12, 23, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Center radiant flare
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Enemies
    for (const e of enemies) {
      if (e.hp <= 0) continue;
      ctx.save();
      ctx.translate(e.x, e.y);

      // Stun vibration
      if (e.stun > 0) {
        ctx.translate((Math.random() - 0.5) * 4, 0);
      }

      ctx.shadowBlur = e.boss ? 25 : 13;
      ctx.shadowColor = e.boss ? '#c27bff' : '#ff658f';

      // Enemy Main Body Carapace
      ctx.fillStyle = e.boss
        ? e.kind === 'riftlord'
          ? '#7542a1'
          : '#583b83'
        : e.kind === 'wraith'
        ? '#3b7890'
        : '#512c56';

      // Rounded torso
      ctx.beginPath();
      this.drawRoundRect(ctx, 2, 8, e.w - 4, e.h - 8, e.boss ? 12 : 7);
      ctx.fill();

      // Glowing Eyes / Optic Sensors
      ctx.fillStyle = e.boss ? '#f7b5ff' : '#ff8fb4';
      ctx.fillRect(7, 15, 5, 4);
      ctx.fillRect(e.w - 12, 15, 5, 4);

      // Boss Ornate Horns & Crest
      if (e.boss) {
        ctx.fillStyle = '#e6c6ff';
        // Left horn
        ctx.beginPath();
        ctx.moveTo(7, 10);
        ctx.lineTo(0, -6);
        ctx.lineTo(14, 5);
        ctx.closePath();
        ctx.fill();

        // Right horn
        ctx.beginPath();
        ctx.moveTo(e.w - 7, 10);
        ctx.lineTo(e.w, -6);
        ctx.lineTo(e.w - 14, 5);
        ctx.closePath();
        ctx.fill();

        if (e.kind === 'riftlord') {
          // Central demonic crest
          ctx.beginPath();
          ctx.moveTo(e.w / 2, -10);
          ctx.lineTo(e.w / 2 - 8, 4);
          ctx.lineTo(e.w / 2 + 8, 4);
          ctx.closePath();
          ctx.fill();
        }
      }

      ctx.restore();

      // Overhead Mini Health Bar
      ctx.fillStyle = '#321f48';
      ctx.fillRect(e.x, e.y - 12, e.w, 4);
      ctx.fillStyle = e.boss ? '#d58cff' : '#ff658f';
      ctx.fillRect(e.x, e.y - 12, (e.w * Math.max(0, e.hp)) / e.maxHp, 4);

      // Boss Title Label
      if (e.boss) {
        ctx.fillStyle = '#e3d7ff';
        ctx.font = 'bold 10px system-ui, sans-serif';
        ctx.fillText(e.kind === 'riftlord' ? 'RIFT LORD' : 'ABBEY GUARDIAN', e.x - 8, e.y - 18);
      }
    }

    // Player Character
    ctx.save();
    if (player.invuln > 0 && Math.floor(player.invuln / 6) % 2 === 0) {
      ctx.globalAlpha = 0.35;
    }
    ctx.translate(player.x, player.y);

    // Dynamic Gravity Flip Smooth Tilt/Orientation
    if (player.grav === -1) {
      ctx.translate(player.w / 2, player.h / 2);
      ctx.scale(1, -1);
      ctx.translate(-player.w / 2, -player.h / 2);
    }

    ctx.shadowBlur = 17;
    ctx.shadowColor = '#69e9ff';

    // Player Robe Body
    ctx.fillStyle = '#5ac5e8';
    ctx.beginPath();
    this.drawRoundRect(ctx, 4, 9, 20, 27, 6);
    ctx.fill();

    // Hood / Helm
    ctx.fillStyle = '#d7f7ff';
    ctx.beginPath();
    ctx.arc(14, 7, 10, 0, Math.PI * 2);
    ctx.fill();

    // Eye Visor
    ctx.fillStyle = '#26395d';
    ctx.fillRect(player.face === 1 ? 16 : 7, 5, 4, 3);

    // Boots / Greaves
    ctx.fillStyle = '#d1e0ff';
    ctx.fillRect(4, 27, 8, 10);
    ctx.fillRect(17, 27, 8, 10);

    // Sword Slash Attack Arc
    if (player.attackTimer > 0) {
      ctx.strokeStyle = '#f3ffff';
      ctx.lineWidth = 4;
      ctx.shadowBlur = 22;
      ctx.shadowColor = '#77f6ff';
      ctx.beginPath();
      ctx.moveTo(14, 21);
      ctx.lineTo(14 + player.face * 42, 8);
      ctx.stroke();

      ctx.strokeStyle = '#77f6ff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(14, 21);
      ctx.lineTo(14 + player.face * 42, 8);
      ctx.stroke();
    }

    // Radiant Energy Shield Barrier
    if (player.shield) {
      ctx.strokeStyle = '#6af4ff';
      ctx.lineWidth = 3;
      ctx.shadowBlur = 18;
      ctx.shadowColor = '#6af4ff';
      ctx.beginPath();
      ctx.arc(14, 18, 28, -1.2, 1.2);
      ctx.stroke();
    }
    ctx.restore();

    // Particles
    for (const p of particles) {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, p.size, p.size);
    }
    ctx.globalAlpha = 1;

    ctx.restore(); // Restore world space

    // 6. Boss Grand Health Bar (Screen Space - Top Center)
    const boss = enemies.find((e) => e.boss);
    if (boss && boss.hp > 0) {
      const barW = width * 0.48;
      const barX = (width - barW) / 2;
      const barY = 28;

      ctx.fillStyle = '#12142b';
      ctx.fillRect(barX, barY, barW, 8);
      ctx.fillStyle = '#cc86ff';
      ctx.fillRect(barX, barY, (barW * Math.max(0, boss.hp)) / boss.maxHp, 8);
      ctx.strokeStyle = '#7b659f';
      ctx.lineWidth = 1;
      ctx.strokeRect(barX, barY, barW, 8);

      ctx.fillStyle = '#f3e8ff';
      ctx.font = 'bold 11px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(
        `${boss.kind === 'riftlord' ? 'RIFT LORD' : 'ABBEY GUARDIAN'} [${boss.hp}/${boss.maxHp}]`,
        width / 2,
        barY - 5
      );
      ctx.textAlign = 'left';
    }

    // 7. Toast Banner Announcement
    if (toastTime > 0) {
      ctx.save();
      ctx.font = 'bold 14px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#a9fff8';
      ctx.shadowBlur = 14;
      ctx.shadowColor = '#5af5ee';
      ctx.fillText(toast, width / 2, height * 0.18);
      ctx.restore();
    }

    // 8. Screen Flash Effect
    if (screenFlash > 0) {
      ctx.fillStyle = `rgba(100, 240, 255, ${screenFlash * 0.015})`;
      ctx.fillRect(0, 0, width, height);
    }

    // 9. Paused Overlay
    if (paused) {
      ctx.fillStyle = 'rgba(5, 9, 22, 0.75)';
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 28px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('PAUSED', width / 2, height / 2);
      ctx.textAlign = 'left';
    }
  }

  private drawRoundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    radius: number
  ) {
    if (ctx.roundRect) {
      ctx.roundRect(x, y, w, h, radius);
    } else {
      ctx.rect(x, y, w, h);
    }
  }
}
