import React, { useState } from 'react';
import { PlayerProfile } from '../types/game';
import { gameStorage } from '../game/storage';
import { User, Edit3, Shield, Swords, Zap, Heart, Check, X } from 'lucide-react';

interface CharacterModalProps {
  onClose: () => void;
  onProfileUpdated?: () => void;
}

export const CharacterModal: React.FC<CharacterModalProps> = ({ onClose, onProfileUpdated }) => {
  const profile = gameStorage.getProfile();
  const [isEditing, setIsEditing] = useState(false);
  const [nameInput, setNameInput] = useState(profile.name);

  const handleSave = () => {
    const trimmed = nameInput.trim() || 'Player';
    gameStorage.saveProfile({ name: trimmed });
    setIsEditing(false);
    if (onProfileUpdated) onProfileUpdated();
  };

  const handleCancel = () => {
    setNameInput(profile.name);
    setIsEditing(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative max-w-lg w-full bg-slate-950/95 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-5">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 bg-sky-400 rounded-full animate-pulse" />
            <h2 className="font-['Cinzel'] font-black text-xl text-slate-100 tracking-wider">
              Character Profile
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Identity Card */}
        <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 mb-5">
          {/* Avatar Frame */}
          <div className="relative w-16 h-16 rounded-xl bg-gradient-to-br from-sky-900 to-slate-950 border-2 border-sky-500/60 flex items-center justify-center text-sky-200 shadow-lg">
            <User className="w-8 h-8" />
            <span className="absolute -bottom-2 -right-2 px-1.5 py-0.5 rounded-full bg-slate-950 border border-sky-400 text-[10px] font-mono font-bold text-sky-300">
              01
            </span>
          </div>

          {/* Name & Title */}
          <div className="flex-1">
            {isEditing ? (
              <div className="flex items-center gap-2 mb-1">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  maxLength={16}
                  className="px-2.5 py-1 rounded bg-slate-950 border border-sky-500 text-sm font-['Cinzel'] font-bold text-white focus:outline-none"
                  autoFocus
                />
                <button
                  onClick={handleSave}
                  className="p-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white"
                  title="Save"
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  onClick={handleCancel}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400"
                  title="Cancel"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 mb-1">
                <span className="font-['Cinzel'] font-black text-lg text-slate-100">
                  {profile.name}
                </span>
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-sky-400 transition"
                  title="Edit Name"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
            <div className="text-xs text-sky-400/90 font-['Cinzel'] uppercase tracking-widest font-semibold">
              {profile.title}
            </div>
          </div>
        </div>

        {/* Real Stats Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-5 font-mono text-xs">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
            <Heart className="w-4 h-4 text-rose-400 mx-auto mb-1" />
            <div className="text-[10px] text-slate-400 uppercase font-['Cinzel']">Health</div>
            <div className="font-bold text-slate-200">4 Hearts</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
            <Swords className="w-4 h-4 text-amber-400 mx-auto mb-1" />
            <div className="text-[10px] text-slate-400 uppercase font-['Cinzel']">Damage</div>
            <div className="font-bold text-slate-200">1 Slash</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
            <Zap className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
            <div className="text-[10px] text-slate-400 uppercase font-['Cinzel']">Speed</div>
            <div className="font-bold text-slate-200">3.50 m/s</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
            <Shield className="w-4 h-4 text-sky-400 mx-auto mb-1" />
            <div className="text-[10px] text-slate-400 uppercase font-['Cinzel']">Barrier</div>
            <div className="font-bold text-slate-200">Active (E)</div>
          </div>
        </div>

        {/* Lore Box */}
        <div className="p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/80 text-xs text-slate-300 leading-relaxed font-sans mb-5">
          <div className="font-['Cinzel'] font-bold text-sky-300 mb-1">Mark of the Inversion</div>
          A lone warrior attuned to the celestial rift, capable of standing upon upside-down cathedral monoliths and defying gravity to reclaim the shattered echoes.
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-200 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
