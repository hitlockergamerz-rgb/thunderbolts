import React from 'react';
import { Zap, Swords, Shield, X, Sparkles } from 'lucide-react';

interface SkillsModalProps {
  onClose: () => void;
}

export const SkillsModal: React.FC<SkillsModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative max-w-lg w-full bg-slate-950/95 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-5">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-sky-400" />
            <h2 className="font-['Cinzel'] font-black text-xl text-slate-100 tracking-wider">
              Warrior Abilities
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Skills Cards */}
        <div className="space-y-3">
          {/* Skill 1: Void Inversion */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-sky-500/40 flex items-start gap-3.5 shadow-md">
            <div className="p-2.5 rounded-xl bg-sky-950/80 border border-sky-500 text-sky-300">
              <Zap className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="font-['Cinzel'] font-bold text-sm text-sky-200">
                  Void Inversion
                </span>
                <span className="px-2 py-0.5 rounded bg-sky-950 text-sky-300 text-[10px] font-mono border border-sky-600/50">
                  Key: Q / Space
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                Inverts personal gravity instantaneously. Walk on ceilings, traverse inverted abbey ruins, and bypass bottomless chasms.
              </p>
            </div>
          </div>

          {/* Skill 2: Echo Strike */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-amber-500/40 flex items-start gap-3.5 shadow-md">
            <div className="p-2.5 rounded-xl bg-amber-950/80 border border-amber-500 text-amber-300">
              <Swords className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="font-['Cinzel'] font-bold text-sm text-amber-200">
                  Echo Strike
                </span>
                <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 text-[10px] font-mono border border-amber-600/50">
                  Key: F / ⚔
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                Unleashes an energetic luminous blade arc that slices shadow stalkers and inflicts heavy critical damage during boss vulnerability windows.
              </p>
            </div>
          </div>

          {/* Skill 3: Radiant Barrier */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-cyan-500/40 flex items-start gap-3.5 shadow-md">
            <div className="p-2.5 rounded-xl bg-cyan-950/80 border border-cyan-500 text-cyan-300">
              <Shield className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="font-['Cinzel'] font-bold text-sm text-cyan-200">
                  Radiant Barrier
                </span>
                <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 text-[10px] font-mono border border-cyan-600/50">
                  Hold: E / 🛡
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                Projects a defensive crystal dome. Enemy contacts bounce off and are momentarily stunned instead of damaging you.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-200 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
