import React, { useEffect, useRef, useState } from 'react';
import { GameEngine } from '../game/engine';
import { HUD } from './HUD';
import { ArrowLeft, ArrowRight, ArrowUp, RefreshCw, Shield, Swords, Zap } from 'lucide-react';

interface GameCanvasProps {
  onReturnToMenu: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({ onReturnToMenu }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [, setTick] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Resize handler to maintain sharp DPR
    const handleResize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const engine = new GameEngine(canvas);
    engineRef.current = engine;

    engine.onStateChange = () => {
      setTick((t) => t + 1);
    };

    engine.start();

    // Keyboard controls
    const onKeyDown = (e: KeyboardEvent) => {
      if (!engineRef.current) return;
      const k = e.key;
      const eng = engineRef.current;

      if ([' ', 'ArrowUp', 'ArrowLeft', 'ArrowRight'].includes(k)) {
        e.preventDefault();
      }

      eng.keys[k] = true;

      if (k === 'q' || k === 'Q') {
        eng.keyAction('flip');
      } else if (k === 'f' || k === 'F') {
        eng.keyAction('attack');
      } else if (k === 'e' || k === 'E') {
        eng.player.shield = true;
      } else if (k === 'Escape' && eng.mode === 'play') {
        eng.paused = true;
        eng.mode = 'paused';
        setTick((t) => t + 1);
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      if (!engineRef.current) return;
      const k = e.key;
      const eng = engineRef.current;
      eng.keys[k] = false;

      if (k === 'e' || k === 'E') {
        eng.player.shield = false;
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      engine.stop();
    };
  }, []);

  const triggerKeyAction = (action: 'flip' | 'attack') => {
    if (engineRef.current) {
      engineRef.current.keyAction(action);
    }
  };

  const setKeyState = (key: string, state: boolean) => {
    if (engineRef.current) {
      engineRef.current.keys[key] = state;
      if (key === 'shield') {
        engineRef.current.player.shield = state;
      }
    }
  };

  return (
    <div className="relative w-full h-full bg-[#070b18] flex flex-col items-center justify-center overflow-hidden select-none touch-none">
      {/* Game Canvas */}
      <canvas ref={canvasRef} className="block w-full h-full flex-1 touch-none" />

      {/* HUD & Modals */}
      {engineRef.current && (
        <HUD
          engine={engineRef.current}
          onRefresh={() => setTick((t) => t + 1)}
          onReturnToMenu={onReturnToMenu}
        />
      )}

      {/* Touch Onscreen Controls for Mobile / Tablets */}
      <div className="absolute bottom-3 left-0 right-0 z-30 flex justify-between items-end px-3 sm:px-6 pointer-events-none">
        {/* Left D-Pad */}
        <div className="flex gap-2 pointer-events-auto">
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              setKeyState('left', true);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              setKeyState('left', false);
            }}
            onPointerCancel={() => setKeyState('left', false)}
            className="w-13 h-13 sm:w-14 sm:h-14 rounded-xl bg-slate-900/85 border border-slate-700/80 active:bg-sky-500/40 flex items-center justify-center text-white backdrop-blur shadow-xl"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              setKeyState('right', true);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              setKeyState('right', false);
            }}
            onPointerCancel={() => setKeyState('right', false)}
            className="w-13 h-13 sm:w-14 sm:h-14 rounded-xl bg-slate-900/85 border border-slate-700/80 active:bg-sky-500/40 flex items-center justify-center text-white backdrop-blur shadow-xl"
          >
            <ArrowRight className="w-6 h-6" />
          </button>
        </div>

        {/* Right Action Cluster */}
        <div className="flex gap-2 pointer-events-auto items-end">
          {/* Shield Button */}
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              setKeyState('shield', true);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              setKeyState('shield', false);
            }}
            onPointerCancel={() => setKeyState('shield', false)}
            className="w-12 h-12 rounded-xl bg-slate-900/85 border border-cyan-500/50 active:bg-cyan-500/40 flex flex-col items-center justify-center text-cyan-300 backdrop-blur shadow-lg text-[10px] font-bold"
          >
            <Shield className="w-5 h-5 mb-0.5" />
            <span>SHLD</span>
          </button>

          {/* Jump Button */}
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              setKeyState('jump', true);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              setKeyState('jump', false);
            }}
            onPointerCancel={() => setKeyState('jump', false)}
            className="w-13 h-13 sm:w-14 sm:h-14 rounded-xl bg-slate-800/85 border border-slate-600 active:bg-slate-700 flex flex-col items-center justify-center text-white backdrop-blur shadow-xl text-[10px] font-bold uppercase tracking-wider"
          >
            <ArrowUp className="w-5 h-5 mb-0.5" />
            <span>JUMP</span>
          </button>

          {/* Attack Button */}
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              triggerKeyAction('attack');
            }}
            className="w-13 h-13 sm:w-14 sm:h-14 rounded-xl bg-amber-950/85 border border-amber-500/60 active:bg-amber-700 flex flex-col items-center justify-center text-amber-200 backdrop-blur shadow-xl text-[10px] font-bold uppercase tracking-wider"
          >
            <Swords className="w-5 h-5 mb-0.5" />
            <span>⚔</span>
          </button>

          {/* Flip Gravity Button */}
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              triggerKeyAction('flip');
            }}
            className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-sky-950/90 border border-sky-400 active:bg-sky-700 flex flex-col items-center justify-center text-sky-200 backdrop-blur shadow-2xl text-[10px] font-bold uppercase tracking-wider"
          >
            <Zap className="w-6 h-6 mb-0.5" />
            <span>⇅ FLIP</span>
          </button>
        </div>
      </div>
    </div>
  );
};
