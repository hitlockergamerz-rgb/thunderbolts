import React from 'react';
import { gameStorage } from '../game/storage';
import { Award, Lock, CheckCircle2, X } from 'lucide-react';

interface AchievementsModalProps {
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({ onClose }) => {
  const achievements = gameStorage.getAchievements();
  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative max-w-lg w-full bg-slate-950/95 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-5">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h2 className="font-['Cinzel'] font-black text-xl text-slate-100 tracking-wider">
              Achievements
            </h2>
            <span className="ml-2 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-[10px] font-mono font-bold text-amber-300">
              {unlockedCount} / {achievements.length} Unlocked
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Achievements List */}
        <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
          {achievements.map((ach) => (
            <div
              key={ach.id}
              className={`flex items-start gap-3.5 p-3.5 rounded-xl border transition-all ${
                ach.unlocked
                  ? 'bg-gradient-to-r from-amber-950/40 via-slate-900/80 to-slate-900/60 border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.15)]'
                  : 'bg-slate-900/40 border-slate-800/80 opacity-60'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 border ${
                  ach.unlocked
                    ? 'bg-amber-950/60 border-amber-500 text-amber-300 shadow-md'
                    : 'bg-slate-800/60 border-slate-700 text-slate-500'
                }`}
              >
                {ach.unlocked ? ach.icon : <Lock className="w-4 h-4 text-slate-500" />}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between mb-0.5">
                  <h3
                    className={`font-['Cinzel'] font-bold text-xs uppercase tracking-wider ${
                      ach.unlocked ? 'text-amber-200' : 'text-slate-400'
                    }`}
                  >
                    {ach.title}
                  </h3>
                  {ach.unlocked && (
                    <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                      <CheckCircle2 className="w-3 h-3" /> Unlocked
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                  {ach.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-200 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
