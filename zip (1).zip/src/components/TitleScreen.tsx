import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Settings as SettingsIcon,
  User,
  Award,
  LogOut,
  Sparkles,
  ChevronRight,
  Shield,
  Volume2,
  VolumeX,
  Power,
  Backpack,
} from 'lucide-react';
import { gameStorage } from '../game/storage';
import { SettingsModal } from './SettingsModal';
import { CharacterModal } from './CharacterModal';
import { AchievementsModal } from './AchievementsModal';
import { QuitModal } from './QuitModal';
import { SkillsModal } from './SkillsModal';
import { InventoryModal } from './InventoryModal';

interface TitleScreenProps {
  onStartGame: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({ onStartGame }) => {
  const [activeModal, setActiveModal] = useState<
    'settings' | 'character' | 'achievements' | 'quit' | 'skills' | 'inventory' | null
  >(null);
  const [profile, setProfile] = useState(gameStorage.getProfile());
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Keyboard shortcut: Space triggers Play when menu is active and no modal is open
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeModal !== null) return;
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        onStartGame();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeModal, onStartGame]);

  // Subtle living atmospheric embers canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Drifting embers and celestial dust
    const embers: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      alpha: number;
      maxAlpha: number;
      color: string;
      life: number;
      maxLife: number;
    }> = [];

    for (let i = 0; i < 35; i++) {
      embers.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.4 + 0.2, // drifting right/up
        vy: -(Math.random() * 0.6 + 0.2),
        size: Math.random() * 2.5 + 1,
        alpha: 0,
        maxAlpha: Math.random() * 0.6 + 0.2,
        color: Math.random() > 0.4 ? '#f43f5e' : '#38bdf8',
        life: Math.random() * 200,
        maxLife: 200 + Math.random() * 150,
      });
    }

    const renderEmbers = () => {
      ctx.clearRect(0, 0, width, height);

      for (const e of embers) {
        e.x += e.vx;
        e.y += e.vy;
        e.life++;

        // Fade in and out
        const half = e.maxLife / 2;
        if (e.life < half) {
          e.alpha = (e.life / half) * e.maxAlpha;
        } else {
          e.alpha = (1 - (e.life - half) / half) * e.maxAlpha;
        }

        if (e.life >= e.maxLife || e.y < -10 || e.x > width + 10) {
          e.x = Math.random() * width * 0.8;
          e.y = height + 10;
          e.life = 0;
        }

        ctx.save();
        ctx.fillStyle = e.color;
        ctx.globalAlpha = Math.max(0, e.alpha);
        ctx.shadowBlur = 6;
        ctx.shadowColor = e.color;
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      animId = requestAnimationFrame(renderEmbers);
    };

    renderEmbers();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  const refreshProfile = () => {
    setProfile(gameStorage.getProfile());
  };

  return (
    <div className="relative w-full h-full bg-[#050813] overflow-hidden select-none font-sans text-slate-100 flex flex-col justify-between">
      {/* 1. Cinematic Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-1000 scale-100"
        style={{
          backgroundImage: `url('/menu_bg.jpg')`,
        }}
      />

      {/* Atmospheric Vignette & Contrast Gradients */}
      <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-slate-950/40 to-transparent pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-slate-950/70 pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_35%,transparent_20%,rgba(5,8,19,0.7)_80%)] pointer-events-none" />

      {/* Floating Canvas Embers */}
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-10" />

      {/* 2. TOP HEADER NAVIGATION */}
      <header className="relative z-20 flex items-center justify-between px-4 sm:px-8 py-4 sm:py-5">
        {/* Top-Left: Player Profile Badge */}
        <div
          onClick={() => setActiveModal('character')}
          className="group flex items-center gap-3 cursor-pointer transition-transform hover:scale-102"
          title="Click to view/edit Character Profile"
        >
          {/* Avatar Box with Diamond Level Tag */}
          <div className="relative w-12 h-12 rounded-xl bg-slate-950/80 border border-slate-700/80 group-hover:border-sky-500/80 flex items-center justify-center backdrop-blur-md shadow-xl transition-colors">
            <User className="w-6 h-6 text-slate-300 group-hover:text-sky-300 transition-colors" />
            <div className="absolute -bottom-1.5 -right-1.5 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-[9px] font-mono font-bold text-sky-400">
              01
            </div>
          </div>

          <div>
            <div className="font-['Cinzel'] font-bold text-sm text-slate-100 group-hover:text-sky-200 transition-colors flex items-center gap-1.5">
              <span>{profile.name}</span>
            </div>
            <div className="text-[11px] text-slate-400 font-['Cinzel'] tracking-wider">
              {profile.title}
            </div>
          </div>
        </div>

        {/* Top-Center Subnav */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-['Cinzel'] tracking-widest uppercase font-semibold text-slate-300">
          <button
            onClick={() => setActiveModal('skills')}
            className="flex items-center gap-1.5 hover:text-sky-400 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>Skills</span>
          </button>
          <button
            onClick={() => setActiveModal('inventory')}
            className="flex items-center gap-1.5 hover:text-amber-400 transition-colors"
          >
            <Backpack className="w-3.5 h-3.5 text-amber-400" />
            <span>Inventory</span>
          </button>
          <button
            onClick={() => setActiveModal('settings')}
            className="flex items-center gap-1.5 hover:text-rose-400 transition-colors"
          >
            <SettingsIcon className="w-3.5 h-3.5 text-rose-400" />
            <span>Settings</span>
          </button>
        </nav>

        {/* Top-Right: Currencies & Power Button */}
        <div className="flex items-center gap-3">
          {/* Shard Currency */}
          <button
            onClick={() => setActiveModal('inventory')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-950/70 border border-slate-800/80 backdrop-blur-md text-xs font-mono text-sky-300 hover:border-sky-500/50 transition shadow-md"
            title="Echo Shards"
          >
            <span>💎</span>
            <span className="font-bold">0</span>
            <span className="text-slate-500 text-[10px]">+</span>
          </button>

          {/* Relic Currency */}
          <button
            onClick={() => setActiveModal('inventory')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-950/70 border border-slate-800/80 backdrop-blur-md text-xs font-mono text-amber-300 hover:border-amber-500/50 transition shadow-md"
            title="Sanctum Relics"
          >
            <span>⭐</span>
            <span className="font-bold">0</span>
            <span className="text-slate-500 text-[10px]">+</span>
          </button>

          {/* Power Button (Quit) */}
          <button
            onClick={() => setActiveModal('quit')}
            className="p-2 rounded-xl bg-slate-950/70 hover:bg-rose-950/60 border border-slate-800/80 hover:border-rose-500/60 text-slate-400 hover:text-rose-300 transition backdrop-blur-md shadow-md"
            title="Exit Application"
          >
            <Power className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Top-Right Atmospheric Quote */}
      <div className="hidden lg:block absolute top-24 right-8 z-20 text-right pointer-events-none">
        <div className="font-['Cinzel'] tracking-[0.25em] text-[11px] text-slate-400/90 uppercase leading-relaxed font-semibold">
          Not Just
          <br />
          A Journey...
          <br />
          <span className="text-rose-400/90 font-bold">But A Choice.</span>
        </div>
      </div>

      {/* 3. CENTER / LEFT MAIN MENU SECTION */}
      <div className="relative z-20 flex-1 flex flex-col justify-center px-4 sm:px-12 md:px-16 max-w-2xl py-6">
        {/* Title Branding Block */}
        <div className="mb-8">
          {/* Main Title: INVERSION with Glowing Red Crescent wrap */}
          <div className="relative inline-block">
            <h1 className="relative font-['Cinzel'] font-black text-4xl sm:text-6xl md:text-7xl tracking-wider text-slate-100 drop-shadow-[0_0_40px_rgba(244,63,94,0.35)] flex items-center">
              {/* Crescent Eclipse Accent behind/around the 'I' */}
              <span className="relative inline-flex items-center justify-center mr-1 text-rose-500">
                <span className="absolute -inset-2 rounded-full border-2 border-rose-500/70 border-r-transparent animate-spin-slow opacity-80" />
                I
              </span>
              <span>NVERSION</span>
            </h1>
          </div>

          {/* Subtitle with Red Accent Dashes */}
          <div className="flex items-center gap-3 mt-1.5">
            <span className="h-[1px] w-6 bg-rose-500/80" />
            <h2 className="font-['Cinzel'] font-bold text-xs sm:text-sm tracking-[0.3em] uppercase text-slate-200">
              Echoes of Two Worlds
            </h2>
            <span className="h-[1px] w-6 bg-rose-500/80" />
          </div>

          {/* Tagline */}
          <div className="mt-3 text-[10px] sm:text-[11px] font-['Cinzel'] tracking-[0.25em] text-slate-400 uppercase font-semibold flex items-center gap-2">
            <span>Same World</span>
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block" />
            <span>Opposite Rules</span>
          </div>
        </div>

        {/* 4. VERTICAL NAVIGATION BUTTONS */}
        <div className="flex flex-col gap-3 max-w-xs">
          {/* PRIMARY: PLAY BUTTON */}
          <button
            onClick={onStartGame}
            className="group relative flex items-center gap-4 px-6 py-3.5 rounded-xl bg-gradient-to-r from-rose-700 via-rose-800 to-rose-950/80 hover:from-rose-600 hover:to-rose-900 border-l-4 border-rose-400 shadow-[0_0_35px_rgba(225,29,72,0.45)] transition-all duration-300 hover:translate-x-1.5 active:scale-98 text-left"
          >
            <div className="w-7 h-7 rounded-lg bg-white/15 flex items-center justify-center text-white shrink-0 group-hover:scale-110 transition-transform">
              <Play className="w-4 h-4 fill-white" />
            </div>
            <div>
              <span className="font-['Cinzel'] font-black text-base sm:text-lg tracking-widest uppercase text-white block">
                Play
              </span>
            </div>
            <div className="ml-auto text-rose-300 opacity-0 group-hover:opacity-100 transition-opacity">
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          {/* SECONDARY: SETTINGS */}
          <button
            onClick={() => setActiveModal('settings')}
            className="group flex items-center gap-4 px-5 py-3 rounded-xl bg-slate-950/70 hover:bg-slate-900/90 border border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-white transition-all duration-200 hover:translate-x-1 backdrop-blur-md shadow-md text-left"
          >
            <SettingsIcon className="w-4 h-4 text-slate-400 group-hover:text-rose-400 transition-colors" />
            <span className="font-['Cinzel'] font-bold text-xs sm:text-sm tracking-widest uppercase">
              Settings
            </span>
          </button>

          {/* SECONDARY: CHARACTER */}
          <button
            onClick={() => setActiveModal('character')}
            className="group flex items-center gap-4 px-5 py-3 rounded-xl bg-slate-950/70 hover:bg-slate-900/90 border border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-white transition-all duration-200 hover:translate-x-1 backdrop-blur-md shadow-md text-left"
          >
            <User className="w-4 h-4 text-slate-400 group-hover:text-sky-400 transition-colors" />
            <span className="font-['Cinzel'] font-bold text-xs sm:text-sm tracking-widest uppercase">
              Character
            </span>
          </button>

          {/* SECONDARY: ACHIEVEMENTS */}
          <button
            onClick={() => setActiveModal('achievements')}
            className="group flex items-center gap-4 px-5 py-3 rounded-xl bg-slate-950/70 hover:bg-slate-900/90 border border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-white transition-all duration-200 hover:translate-x-1 backdrop-blur-md shadow-md text-left"
          >
            <Award className="w-4 h-4 text-slate-400 group-hover:text-amber-400 transition-colors" />
            <span className="font-['Cinzel'] font-bold text-xs sm:text-sm tracking-widest uppercase">
              Achievements
            </span>
          </button>

          {/* SECONDARY: QUIT */}
          <button
            onClick={() => setActiveModal('quit')}
            className="group flex items-center gap-4 px-5 py-3 rounded-xl bg-slate-950/70 hover:bg-slate-900/90 border border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-rose-300 transition-all duration-200 hover:translate-x-1 backdrop-blur-md shadow-md text-left"
          >
            <LogOut className="w-4 h-4 text-slate-400 group-hover:text-rose-400 transition-colors" />
            <span className="font-['Cinzel'] font-bold text-xs sm:text-sm tracking-widest uppercase">
              Quit
            </span>
          </button>
        </div>
      </div>

      {/* 5. BOTTOM BAR: ATMOSPHERIC CAPTION & CHAPTER 1 CARD */}
      <footer className="relative z-20 flex items-end justify-between px-4 sm:px-8 py-4 sm:py-5 pointer-events-none">
        {/* Bottom-Left: Atmospheric Audio Glyph & Caption */}
        <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 backdrop-blur-md shadow-lg pointer-events-auto">
          {/* Soundwave Bars */}
          <div className="flex items-end gap-0.5 h-3 text-slate-400">
            <span className="w-0.5 h-2 bg-slate-400 animate-pulse" />
            <span className="w-0.5 h-3 bg-slate-400 animate-pulse delay-75" />
            <span className="w-0.5 h-1.5 bg-slate-400 animate-pulse delay-150" />
            <span className="w-0.5 h-2.5 bg-slate-400 animate-pulse delay-100" />
          </div>
          <span className="font-['Cinzel'] tracking-widest text-[10px] text-slate-400 uppercase font-semibold">
            A New World Awaits...
          </span>
        </div>

        {/* Bottom-Right: Chapter 1 Card */}
        <div
          onClick={onStartGame}
          className="group cursor-pointer flex items-center gap-3 p-2 sm:p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-900/90 border border-slate-800 hover:border-sky-500/60 backdrop-blur-md transition-all shadow-xl pointer-events-auto hover:translate-y-[-2px]"
          title="Start Chapter 1: The Beginning"
        >
          {/* Thumbnail Preview */}
          <div className="w-14 h-9 sm:w-16 sm:h-10 rounded-lg bg-slate-900 border border-slate-700 overflow-hidden relative shrink-0">
            <img
              src="/menu_bg.jpg"
              alt="Chapter 1"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-sky-950/30" />
          </div>

          <div>
            <div className="font-['Cinzel'] tracking-widest text-[9px] sm:text-[10px] text-sky-400 uppercase font-bold">
              Chapter 1
            </div>
            <div className="font-['Cinzel'] font-bold text-xs sm:text-sm text-slate-100 uppercase tracking-wider group-hover:text-white transition-colors">
              The Beginning
            </div>
          </div>

          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-sky-300 group-hover:translate-x-0.5 transition-all ml-1" />
        </div>
      </footer>

      {/* 6. MODALS */}
      {activeModal === 'settings' && (
        <SettingsModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'character' && (
        <CharacterModal
          onClose={() => setActiveModal(null)}
          onProfileUpdated={refreshProfile}
        />
      )}
      {activeModal === 'achievements' && (
        <AchievementsModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'skills' && (
        <SkillsModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'inventory' && (
        <InventoryModal onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'quit' && (
        <QuitModal
          onClose={() => setActiveModal(null)}
          onConfirmQuit={() => setActiveModal(null)}
        />
      )}
    </div>
  );
};
