import React from 'react';
import { Sparkles, Heart, Swords, Zap, Shield, X } from 'lucide-react';

interface InventoryModalProps {
  onClose: () => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative max-w-lg w-full bg-slate-950/95 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-5">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h2 className="font-['Cinzel'] font-black text-xl text-slate-100 tracking-wider">
              Relic Inventory
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Currency & Relics Grid */}
        <div className="space-y-4">
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-sky-950 border border-sky-500/60 flex items-center justify-center text-sky-400 text-lg">
                💎
              </div>
              <div>
                <div className="font-bold text-slate-200 text-xs font-['Cinzel']">Echo Shards</div>
                <div className="text-[11px] text-slate-400">Collect 3 in each realm to align the dimensional portals</div>
              </div>
            </div>
            <span className="font-mono text-sky-300 font-bold text-sm">3 / Realm</span>
          </div>

          <div className="text-[11px] font-['Cinzel'] text-slate-400 uppercase tracking-widest font-bold">
            Sanctum Relics (Acquired Upon Defeating Realm Guardians)
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-rose-400 font-['Cinzel'] font-bold mb-1">
                <Heart className="w-4 h-4" /> Heartstone
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Extends life force up to 6 hearts.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-amber-400 font-['Cinzel'] font-bold mb-1">
                <Swords className="w-4 h-4" /> Echo Blade
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Sharpens sword attack damage.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-emerald-400 font-['Cinzel'] font-bold mb-1">
                <Zap className="w-4 h-4" /> Swiftstep
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Boosts run velocity and vertical jump reach.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2 text-sky-400 font-['Cinzel'] font-bold mb-1">
                <Shield className="w-4 h-4" /> Rift Capacitor
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Accelerates gravity inversion recharge.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-200 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
