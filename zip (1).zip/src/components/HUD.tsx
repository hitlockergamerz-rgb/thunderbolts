import React from 'react';
import { GameEngine } from '../game/engine';
import { RelicId } from '../types/game';
import { Heart, Shield, Swords, Zap, Volume2, VolumeX, Pause, Play, RotateCcw } from 'lucide-react';
import { sounds } from '../game/audio';

interface HUDProps {
  engine: GameEngine;
  onRefresh: () => void;
  onReturnToMenu: () => void;
}

export const HUD: React.FC<HUDProps> = ({ engine, onRefresh, onReturnToMenu }) => {
  const isSoundOn = sounds.getSoundOn();

  const toggleSound = () => {
    sounds.setSoundOn(!isSoundOn);
    onRefresh();
  };

  const handlePause = () => {
    if (engine.mode === 'play') {
      engine.paused = true;
      engine.mode = 'paused';
    } else if (engine.mode === 'paused') {
      engine.paused = false;
      engine.mode = 'play';
    }
    onRefresh();
  };

  const handleSelectUpgrade = (relic: RelicId) => {
    engine.applyUpgrade(relic);
    onRefresh();
  };

  const handleLevelClearNext = () => {
    if (engine.levelIndex === 0) {
      engine.mode = 'upgrade';
    } else if (engine.levelIndex === 1) {
      engine.mode = 'upgrade';
    } else {
      engine.mode = 'ending';
    }
    onRefresh();
  };

  const shardsRecovered = engine.shards.filter((s) => s.got).length;
  const isNormalGravity = engine.player.grav === 1;

  return (
    <>
      {/* Top Header Bar */}
      <header className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between gap-3 px-3 py-2 sm:px-6 sm:py-3 bg-slate-950/80 border-b border-slate-800/80 backdrop-blur-md pointer-events-auto">
        <div className="flex items-center gap-3">
          <div>
            <div className="text-[10px] tracking-widest text-sky-400 font-['Cinzel'] uppercase font-bold">
              Level {engine.levelIndex + 1}/3
            </div>
            <h2 className="text-xs sm:text-sm md:text-base font-['Cinzel'] font-bold text-slate-100 tracking-wider">
              {engine.level.name}
            </h2>
          </div>
        </div>

        {/* HUD Status Pills */}
        <div className="flex items-center gap-2 text-xs font-mono">
          {/* Health Hearts */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/90 border border-slate-700/70 text-rose-400">
            {Array.from({ length: engine.player.maxHp }).map((_, i) => (
              <span key={i} className="text-sm font-bold">
                {i < engine.player.hp ? '♥' : '♡'}
              </span>
            ))}
          </div>

          {/* Shards Recovered */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/90 border border-slate-700/70 text-sky-300">
            <span className="text-[11px] font-['Cinzel']">Shards</span>
            <span className="font-bold">
              {shardsRecovered}/{engine.shards.length}
            </span>
          </div>

          {/* Gravity Pill */}
          <div
            className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full border transition-all ${
              isNormalGravity
                ? 'bg-sky-950/80 border-sky-500/50 text-sky-200'
                : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
            }`}
          >
            <span>{isNormalGravity ? 'Gravity ↓' : 'Gravity ↑'}</span>
            {engine.flipCd > 0 && (
              <span className="text-[10px] opacity-70">
                {(engine.flipCd / 60).toFixed(1)}s
              </span>
            )}
          </div>

          {/* Audio Toggle */}
          <button
            onClick={toggleSound}
            className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 transition"
            title={isSoundOn ? 'Mute' : 'Unmute'}
          >
            {isSoundOn ? <Volume2 className="w-3.5 h-3.5 text-sky-400" /> : <VolumeX className="w-3.5 h-3.5 text-rose-400" />}
          </button>

          {/* Pause Button */}
          <button
            onClick={handlePause}
            className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 transition"
            title="Pause (Esc)"
          >
            <Pause className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* OVERLAY DIALOGS */}

      {/* 1. Pause Overlay */}
      {engine.mode === 'paused' && (
        <div className="absolute inset-0 z-40 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full p-6 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl text-center">
            <h2 className="font-['Cinzel'] font-black text-2xl text-slate-100 mb-2">Game Paused</h2>
            <p className="text-xs text-slate-400 mb-6 font-sans">
              Your progress in <span className="text-sky-300">{engine.level.name}</span> is preserved.
            </p>
            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  engine.paused = false;
                  engine.mode = 'play';
                  onRefresh();
                }}
                className="py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-white transition shadow-lg"
              >
                Resume
              </button>
              <button
                onClick={() => {
                  engine.loadLevel(engine.levelIndex, false);
                  onRefresh();
                }}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-200 transition"
              >
                Restart Level
              </button>
              <button
                onClick={onReturnToMenu}
                className="py-2.5 px-4 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-400 transition"
              >
                Main Menu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Level Clear Screen */}
      {engine.mode === 'clear' && (
        <div className="absolute inset-0 z-40 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-lg w-full p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-sky-500/60 shadow-[0_0_50px_rgba(56,189,248,0.25)] text-center">
            <div className="inline-flex p-3 rounded-full bg-sky-500/20 text-sky-300 mb-3">
              <Zap className="w-8 h-8" />
            </div>
            <h2 className="font-['Cinzel'] font-black text-2xl sm:text-3xl text-sky-200 tracking-wider mb-2">
              {engine.levelIndex === 0
                ? 'Realm Restored'
                : engine.levelIndex === 1
                ? 'The Abbey Falls Silent'
                : 'Rift Heart Exposed'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mb-6 font-sans">
              {engine.levelIndex === 0
                ? `${engine.level.name} is stable. All echo shards are recovered.`
                : engine.levelIndex === 1
                ? 'The Abbey Guardian is defeated and the second echo is attuned.'
                : 'The final rift guardian has fallen. Prepare to seal the fracture.'}
            </p>
            <button
              onClick={handleLevelClearNext}
              className="py-3 px-8 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 font-['Cinzel'] font-bold text-sm uppercase tracking-wider text-white shadow-xl transition hover:scale-105 active:scale-95"
            >
              {engine.levelIndex < 2 ? 'Claim A Relic' : 'Seal The Rift'}
            </button>
          </div>
        </div>
      )}

      {/* 3. Relic Upgrade Selection */}
      {engine.mode === 'upgrade' && (
        <div className="absolute inset-0 z-40 bg-slate-950/90 backdrop-blur-lg flex items-center justify-center p-4">
          <div className="max-w-xl w-full p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl text-center">
            <div className="text-[11px] font-['Cinzel'] uppercase tracking-widest text-sky-400 font-bold mb-1">
              Sanctum of Echoes
            </div>
            <h2 className="font-['Cinzel'] font-black text-2xl sm:text-3xl text-slate-100 mb-2">
              Choose A Relic
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Guardian defeated. Bind one ancient relic to empower your warrior for the next realm.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
              {/* Heartstone */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-rose-500/60 transition flex flex-col justify-between text-left">
                <div>
                  <div className="flex items-center gap-2 text-rose-400 font-['Cinzel'] font-bold text-sm mb-1">
                    <Heart className="w-4 h-4" /> Heartstone
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-3">
                    Restore all health and permanently gain +1 max heart container.
                  </p>
                </div>
                <button
                  onClick={() => handleSelectUpgrade('heart')}
                  className="w-full py-2 bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/50 rounded-lg text-xs font-['Cinzel'] font-bold uppercase tracking-wider text-rose-200 transition"
                >
                  Select Relic
                </button>
              </div>

              {/* Echo Blade */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/60 transition flex flex-col justify-between text-left">
                <div>
                  <div className="flex items-center gap-2 text-amber-400 font-['Cinzel'] font-bold text-sm mb-1">
                    <Swords className="w-4 h-4" /> Echo Blade
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-3">
                    Hone your blade strikes to deal +1 damage to all shadows and rift guardians.
                  </p>
                </div>
                <button
                  onClick={() => handleSelectUpgrade('blade')}
                  className="w-full py-2 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/50 rounded-lg text-xs font-['Cinzel'] font-bold uppercase tracking-wider text-amber-200 transition"
                >
                  Select Relic
                </button>
              </div>

              {/* Swiftstep */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-emerald-500/60 transition flex flex-col justify-between text-left">
                <div>
                  <div className="flex items-center gap-2 text-emerald-400 font-['Cinzel'] font-bold text-sm mb-1">
                    <Zap className="w-4 h-4" /> Swiftstep
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-3">
                    Increase horizontal sprint velocity (+0.45) and vertical jump reach (+0.5).
                  </p>
                </div>
                <button
                  onClick={() => handleSelectUpgrade('boots')}
                  className="w-full py-2 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/50 rounded-lg text-xs font-['Cinzel'] font-bold uppercase tracking-wider text-emerald-200 transition"
                >
                  Select Relic
                </button>
              </div>

              {/* Rift Capacitor */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-sky-500/60 transition flex flex-col justify-between text-left">
                <div>
                  <div className="flex items-center gap-2 text-sky-400 font-['Cinzel'] font-bold text-sm mb-1">
                    <Shield className="w-4 h-4" /> Rift Capacitor
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-3">
                    Substantially reduce cooldown between gravity inversions.
                  </p>
                </div>
                <button
                  onClick={() => handleSelectUpgrade('rift')}
                  className="w-full py-2 bg-sky-950/60 hover:bg-sky-900/80 border border-sky-500/50 rounded-lg text-xs font-['Cinzel'] font-bold uppercase tracking-wider text-sky-200 transition"
                >
                  Select Relic
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Player Death Screen */}
      {engine.mode === 'dead' && (
        <div className="absolute inset-0 z-40 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full p-6 sm:p-8 rounded-2xl bg-slate-900 border border-rose-900/80 shadow-[0_0_50px_rgba(244,63,94,0.3)] text-center">
            <h2 className="font-['Cinzel'] font-black text-2xl sm:text-3xl text-rose-300 tracking-wider mb-2">
              Your Echo Fades
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              The realm overwhelms your warrior, but the rift remains waiting.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => {
                  engine.loadLevel(engine.levelIndex, false);
                  onRefresh();
                }}
                className="py-2.5 px-6 rounded-xl bg-rose-700 hover:bg-rose-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-white transition shadow-lg"
              >
                Retry Level
              </button>
              <button
                onClick={onReturnToMenu}
                className="py-2.5 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-300 transition"
              >
                Main Menu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. Ending Victory Screen */}
      {engine.mode === 'ending' && (
        <div className="absolute inset-0 z-40 bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="max-w-lg w-full p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-500/70 shadow-[0_0_60px_rgba(245,158,11,0.3)] text-center">
            <h2 className="font-['Cinzel'] font-black text-3xl sm:text-4xl text-amber-200 tracking-wider mb-2">
              The Worlds Are One
            </h2>
            <p className="text-xs font-['Cinzel'] text-amber-400 uppercase tracking-widest mb-4 font-bold">
              Three Realms Restored
            </p>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6 font-sans">
              You defeated the Rift Lord and stabilized all three echoes. The inversion is no longer a curse—it is a choice. Aethelgard and the Abyssal Rift now echo in eternal harmony.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => {
                  engine.loadLevel(0, false);
                  onRefresh();
                }}
                className="py-3 px-6 rounded-xl bg-amber-600 hover:bg-amber-500 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-black transition shadow-xl"
              >
                Play Again
              </button>
              <button
                onClick={onReturnToMenu}
                className="py-3 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-200 transition"
              >
                Main Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
