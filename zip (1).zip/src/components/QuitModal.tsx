import React from 'react';
import { LogOut, X } from 'lucide-react';

interface QuitModalProps {
  onClose: () => void;
  onConfirmQuit: () => void;
}

export const QuitModal: React.FC<QuitModalProps> = ({ onClose, onConfirmQuit }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative max-w-sm w-full bg-slate-950/95 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-center text-slate-100 animate-in fade-in zoom-in-95">
        <div className="w-12 h-12 rounded-2xl bg-rose-950/60 border border-rose-500/50 text-rose-400 mx-auto mb-4 flex items-center justify-center shadow-lg">
          <LogOut className="w-6 h-6" />
        </div>

        <h2 className="font-['Cinzel'] font-black text-xl text-slate-100 mb-2">
          Quit The Journey?
        </h2>

        <p className="text-xs text-slate-400 leading-relaxed mb-6 font-sans">
          Your journey through the fractured realms is safely preserved in this browser session.
        </p>

        <div className="flex flex-col gap-2.5">
          <button
            onClick={onConfirmQuit}
            className="w-full py-2.5 px-4 rounded-xl bg-rose-700 hover:bg-rose-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-white transition shadow-lg"
          >
            Confirm Exit
          </button>
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-300 transition"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
