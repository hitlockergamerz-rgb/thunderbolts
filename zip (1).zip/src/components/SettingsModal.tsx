import React, { useState } from 'react';
import { GameSettings } from '../types/game';
import { gameStorage } from '../game/storage';
import { sounds } from '../game/audio';
import { Volume2, VolumeX, Sparkles, Vibrate, Wind, X } from 'lucide-react';

interface SettingsModalProps {
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const [settings, setSettings] = useState<GameSettings>(gameStorage.getSettings());

  const handleToggle = (key: keyof GameSettings) => {
    const nextVal = !settings[key];
    const updated = { ...settings, [key]: nextVal };
    setSettings(updated);
    gameStorage.saveSettings(updated);

    if (key === 'soundEnabled') {
      sounds.setSoundOn(nextVal);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative max-w-md w-full bg-slate-950/95 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-5">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 bg-rose-500 rounded-full animate-pulse" />
            <h2 className="font-['Cinzel'] font-black text-xl text-slate-100 tracking-wider">
              Settings
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Options List */}
        <div className="space-y-4 text-xs font-sans">
          {/* Master Audio */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 text-sky-400">
                {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-rose-400" />}
              </div>
              <div>
                <div className="font-bold text-slate-200">Sound Effects</div>
                <div className="text-[11px] text-slate-400">Combat slashes, gravity sweeps, pickups</div>
              </div>
            </div>
            <button
              onClick={() => handleToggle('soundEnabled')}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 ${
                settings.soundEnabled ? 'bg-sky-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Ambient Drone */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 text-purple-400">
                <Wind className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-slate-200">Mystic Atmosphere</div>
                <div className="text-[11px] text-slate-400">Background harmonic drone resonance</div>
              </div>
            </div>
            <button
              onClick={() => handleToggle('ambientDrone')}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 ${
                settings.ambientDrone ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.ambientDrone ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Screen Shake */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 text-amber-400">
                <Vibrate className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-slate-200">Screen Shake</div>
                <div className="text-[11px] text-slate-400">Camera rumble on hits and gravity flips</div>
              </div>
            </div>
            <button
              onClick={() => handleToggle('screenShake')}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 ${
                settings.screenShake ? 'bg-amber-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.screenShake ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Particle Effects */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 text-rose-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-slate-200">Embers & Particles</div>
                <div className="text-[11px] text-slate-400">Floating motes and atmospheric fog waves</div>
              </div>
            </div>
            <button
              onClick={() => handleToggle('particleEffects')}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 ${
                settings.particleEffects ? 'bg-rose-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.particleEffects ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-['Cinzel'] font-bold text-xs uppercase tracking-wider text-slate-200 transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
