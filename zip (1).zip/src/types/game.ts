export type RealmType = 'NORMAL' | 'INVERTED';

export type EnemyKind = 'stalker' | 'wraith' | 'abbot' | 'riftlord';

export interface Enemy {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  hp: number;
  maxHp: number;
  kind: EnemyKind;
  min: number;
  max: number;
  dir: number;
  stun: number;
  attack: number;
  phase: number;
  boss: boolean;
}

export interface Player {
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  grav: 1 | -1;
  ground: boolean;
  hp: number;
  maxHp: number;
  face: 1 | -1;
  attackTimer: number; // frames or seconds remaining
  shield: boolean;
  speed: number;
  jump: number;
  damage: number;
  flipPower: number;
  invuln: number;
  rotation: number;
}

export interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
  isCeiling?: boolean;
}

export interface Spike {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Shard {
  id: string;
  x: number;
  y: number;
  got: boolean;
}

export interface Portal {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
}

export interface InputState {
  left: boolean;
  right: boolean;
  jump: boolean;
  flip: boolean;
  attack: boolean;
  shield: boolean;
}

export type RelicId = 'heart' | 'blade' | 'boots' | 'rift';

export interface RelicOption {
  id: RelicId;
  name: string;
  icon: string;
  description: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface GameSettings {
  soundEnabled: boolean;
  ambientDrone: boolean;
  screenShake: boolean;
  particleEffects: boolean;
}

export interface PlayerProfile {
  name: string;
  title: string;
  level: number;
}

export type GameMode = 'title' | 'play' | 'upgrade' | 'clear' | 'dead' | 'ending' | 'paused';

